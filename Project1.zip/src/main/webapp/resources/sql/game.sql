DROP TABLE game;
CREATE TABLE game(
	g_id VARCHAR2(10) NOT NULL,
	g_name VARCHAR2(20),
	g_description VARCHAR2(500),
   	g_category VARCHAR2(20),
	g_manufacturer VARCHAR2(20),
	g_fileName  VARCHAR2(20),
	PRIMARY KEY (g_id)
);