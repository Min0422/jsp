select g.g_id, i.num, i.g_filename 
    from game g, g_img i
    where g.g_id = i.g_id
    order by num;
--  아이디코드를 통해서 이미지 여러개를 행으로 출력