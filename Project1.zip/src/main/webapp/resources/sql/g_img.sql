DROP TABLE g_img;
CREATE TABLE g_img(
	g_id VARCHAR2(10),
    num NUMBER,
	g_fileName  VARCHAR2(20)
);