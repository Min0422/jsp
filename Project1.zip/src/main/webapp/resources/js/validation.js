function CheckAddGame() {
	var gameId = document.getElementById("gameId");
	var name = document.getElementById("name");
	
	//상품 아이디 체크
	if (!check(/^P[0-9]{4,11}$/, gameId, "[상품 코드]\nP와 숫자를 조합하여 5~12자까지 입력하세요\n첫 글자는 반드시 P로 시작하세요"))
		return false;
	
	//상품명 체크
	if (name.value.length <1 || name.value.length >20) {
		alert("[게임명]\n최소 1자에서 최대 20자까지 입력하세요");
		name.select();
		name.focus();
		return false;
	}
	
	document.newGame.submit();
}