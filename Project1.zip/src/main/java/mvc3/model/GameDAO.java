package mvc3.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import mvc1.database.DBConnection;

public class GameDAO {
	
	private static GameDAO instance;
	
	private GameDAO() {
	}
	
	public static GameDAO getInstance() {
		if (instance == null)
			instance = new GameDAO();
		return instance;
	}
	
	public int getListCount(String items, String text) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int x = 0;
		
		String sql;
		
		if(items == null && text == null)
			sql = "select count(*) from game";
		else
			sql = "select count(*) from game where " + items + " like '%" + text + "%'";
		
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next())
				x = rs.getInt(1);
			
		} catch (Exception ex) {
			System.out.println("getGameCount() 에러: " + ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage());
			}
		}
		return x;
	}
	
	public ArrayList<GameDTO> getGameList(int page, int limit, String items, String text) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int total_record = getListCount(items, text);
		int start = (page -1) * limit;
		int index = start + 1;
		
		String sql;
		
		if(items == null && text == null)
			sql = "select * from game order by g_id";
		else
			sql = "select * from game where " + items + " like '%" + text + "%' order by g_id";
		
		ArrayList<GameDTO> list = new ArrayList<GameDTO>();
		
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = pstmt.executeQuery();
			
			while (rs.absolute(index)) {
				GameDTO game = new GameDTO();
				game.setG_id(rs.getString("g_id"));
				game.setG_category(rs.getString("g_category"));
				game.setG_name(rs.getString("g_name"));
				list.add(game);
				
				if(index < (start + limit) && index <= total_record)
					index++;
				else
					break;
			}
			return list;
		} catch (Exception ex) {
			System.out.println("getGameList() 에러 : " + ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage());
			}
		}
		return null;
	}
}
